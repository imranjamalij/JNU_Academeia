# Raspberry Pi and Python projects that I will be working on
There will be videos tied to each project here: https://www.youtube.com/channel/UC4JoAr1y3yNRLlwK_WQ552w

Following are the pre-reqs for getting the BME sensor to work
----------------------------------------------------------------
1. sudo apt-get update
2. sudo apt-get install build-essential python-pip python-dev python-smbus git
3. git clone https://github.com/adafruit/Adafruit_Python_GPIO.git
4. cd Adafruit_Python_GPIO
5. sudo python setup.py install

