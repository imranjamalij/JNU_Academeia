# This program uses the BME_280 sensor using I2c
import sys
import pandas as pd
import numpy as np
import traceback
import time
import RPi.GPIO as GPIO
from Adafruit_BME280 import *

import paho.mqtt.publish as publish


MQTT_SERVER = "192.168.0.11"

degrees = 0
fah = 0
global iteri
iteri=0
hectopascals = 0
humidity = 0

#df = pd.DataFrame()

global df
df = pd.DataFrame(columns=['Date','Temperature','Humidity','Pressure'])

#print("Empty Dataframe", df)




#GPIO.setmode(GPIO.BOARD)


# Looking up the sensor and setting it for output
redpin = 32
greenpin = 37

sensor = BME280(mode=BME280_OSAMPLE_8)
#GPIO.setup(redpin, GPIO.OUT)
#GPIO.setup(greenpin, GPIO.OUT)

def blinkLED():
    # Turning the LEDs on and off
    if fah < 80.0 and fah > 70.0:
        #GPIO.output(greenpin, GPIO.HIGH)
        #GPIO.output(redpin, GPIO.LOW)
        publish.single("device/1/in", "high", hostname=MQTT_SERVER)
        #publish.single("device/2/in", "low", hostname=MQTT_SERVER)
        print("publish dev1")
    else:
        #GPIO.output(greenpin, GPIO.LOW)
        #GPIO.output(redpin, GPIO.HIGH)
        client.publish("device/2/in", "high", hostname=MQTT_SERVER)
        #client.publish("device/1/in", "low", hostname=MQTT_SERVER)
        print("publish dev2")
              


def readSensor():
    global degrees, fah, pascals, hectopascals, humidity,iteri,df

    # Changing the mode to BOARD (pin number on the board)
    degrees = sensor.read_temperature()
    fah = 9.0 / 5.0 * degrees + 32
    pascals = sensor.read_pressure()
    hectopascals = pascals / 100
    humidity = sensor.read_humidity()
    #df.append=[[fah]+[pascals]+[hectopascals] +[humidity]]
    #df=df.append({'Date':fah,'Temperature': 'temp', 'Humidity': 'hum', 'Pressure': 'pres'}, ignore_index=True)
    
    df=df.append({'Date':time.strftime("%Y-%m-%d %H:%M:%S"),'Temperature': fah, 'Humidity': humidity, 'Pressure': hectopascals}, ignore_index=True)
    
    iteri = iteri + 1
    if iteri ==100:
        df.to_csv("tempdata.csv", encoding='utf-8', doublequote=False, index=False, mode="a", header=False)
        df = df[0:0]
        iteri= 0
        
    
        
    
def SensorInfo():
    
    print('Fahrenheit= {0:0.3f} deg F'.format(fah))
    print('Celsius   = {0:0.3f} deg C'.format(degrees))
    print('Pressure  = {0:0.2f} hPa'.format(hectopascals))
    print('Humidity  = {0:0.2f} %'.format(humidity))
    print('==========={0}==========='.format(time.strftime("%Y-%m-%d %H:%M:%S")))
    
    
    

def main_loop() :
    
    try:
        while True:
            readSensor()
            SensorInfo()
            time.sleep(1.0)
    except KeyboardInterrupt:
        print('interruption')
        print(df.head())
        
    
    

# The following makes this program start running at main_loop() 
# when executed as a stand-alone program.    F
if __name__ == '__main__':
    try:
        main_loop()
    except :
        traceback.print_exc(file=sys.stdout)
    finally:
    # reset the sensor before exiting the program
        GPIO.cleanup()
